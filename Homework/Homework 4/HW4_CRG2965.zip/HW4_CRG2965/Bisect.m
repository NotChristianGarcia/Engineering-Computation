function [neededdepth] = Bisect( input_args )
%BISECT Summary of this function goes here
%   Detailed explanation goes here
iterations = 0;

while goal < abs(relerror)
    mid = (a+b)/2;
    if (pi*mid^2*((3*R - mid)/3))
        Break
    end
    iterations = iterations + 1;
    if sign(pi*mid^2*((3*R - mid)/3)) = (pi*a^2*((3*R - a)/3))
        a = c;
    else
        b = c;
    end
end
end